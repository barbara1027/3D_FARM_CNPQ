import { Router } from "express";
import { QualidadeController } from "./qualidadeImpressao.controller";
import { QualidadeService } from "./qualidadeImpressao.service";
import { QualidadeRepository } from "./qualidadeImpressao.repository";

const qualidadesRoutes = Router();

const qualidadeRepository = new QualidadeRepository();
const qualidadeService = new QualidadeService(qualidadeRepository);
const qualidadeController = new QualidadeController(qualidadeService);

qualidadesRoutes.get("/", qualidadeController.listar);
qualidadesRoutes.get("/:id", qualidadeController.buscarPorId);
qualidadesRoutes.post("/", qualidadeController.criar);
qualidadesRoutes.put("/:id", qualidadeController.atualizar);
qualidadesRoutes.delete("/:id", qualidadeController.remover);

export { qualidadesRoutes };